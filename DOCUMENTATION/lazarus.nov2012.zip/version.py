def get_version_string():
    return "version November 2012"